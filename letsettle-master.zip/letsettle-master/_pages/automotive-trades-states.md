---
ID: 473
post_title: Automotive-trades-States
author: Admin-Skrumworx
post_excerpt: ""
layout: page
permalink: >
  http://35.184.23.199/skills/automotive-trades-states/
published: true
post_date: 2018-03-27 11:53:24
---
<p> </p><h5> </h5><noscript><a href='#'><img alt='Automotive Trades ' src='https://public.tableau.com/static/images/Au/AutomotiveTradesbook/AutomotiveTrades/1_rss.png' style='border: none' /></a></noscript><object style="display: none;" width="300" height="150"><param name="host_url" value="https%3A%2F%2Fpublic.tableau.com%2F" /> <param name="embed_code_version" value="3" /> <param name="site_root" value="" /><param name="name" value="AutomotiveTradesbook/AutomotiveTrades" /><param name="tabs" value="no" /><param name="toolbar" value="yes" /><param name="static_image" value="https://public.tableau.com/static/images/Au/AutomotiveTradesbook/AutomotiveTrades/1.png" /> <param name="animate_transition" value="yes" /><param name="display_static_image" value="yes" /><param name="display_spinner" value="yes" /><param name="display_overlay" value="yes" /><param name="display_count" value="yes" /><param name="filter" value="publish=yes" /></object><p></p><p>I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>