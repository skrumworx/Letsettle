---
ID: 18
post_title: Home
author: Admin-Skrumworx
post_excerpt: ""
layout: page
permalink: http://letsettle.net.au/
published: true
post_date: 2018-03-24 22:39:21
---
<h2>Do what is right.</h2>		
			<h2>Life is all about making choices, change and taking chances.</h2>		
										<img src="http://35.184.23.199/wp-content/uploads/elementor/thumbs/THD-nnqfcfap0remvkcsuiuumor29ww27ux8uvpabfq23s.png" title="THD" alt="THD" />											
			<h3>Occupation categories</h3>		
		<p>Most demanded skilled occupations in Australia at the moment</p>		
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/act-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/act-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/act-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/act-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/ict-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/ict-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/ict-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/ict-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/car-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/car-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/car-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/car-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/Building-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/Building-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/Building-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/Building-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/con-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/con-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/con-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/con-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/eng-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/eng-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/eng-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/eng-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/tra-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/tra-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/tra-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/tra-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/hea-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/hea-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/hea-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/hea-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/ning-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/ning-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/ning-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/ning-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
										<img width="1024" height="881" src="http://35.184.23.199/wp-content/uploads/2018/03/t-1024x881.png" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/t-1024x881.png 1024w, http://35.184.23.199/wp-content/uploads/2018/03/t-300x258.png 300w, http://35.184.23.199/wp-content/uploads/2018/03/t-768x661.png 768w" sizes="(max-width: 1024px) 100vw, 1024px" />											
			<h3>Stories </h3>		
										<img width="768" height="1024" src="http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.24.57-PM-768x1024.jpeg" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.24.57-PM.jpeg 768w, http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.24.57-PM-225x300.jpeg 225w" sizes="(max-width: 768px) 100vw, 768px" />											
                <p>
                    As  a professional with 10 years experience in Teaching, I would like to find a job which matches my skills in Australia . Unfortunately, I’m forced drive Uber to cover up my family’s expenses.    This web site helped me to identify the state, which matches my skills the most. And currently I’m working on my PR application to migrate South Australia, which I believe I have a highest chance of getting a job and settle down. 
                </p>
                <p>Sujeewa Ariyarathna</p>
										<img width="710" height="1024" src="http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.19.51-PM-710x1024.jpeg" alt="" srcset="http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.19.51-PM-710x1024.jpeg 710w, http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.19.51-PM-208x300.jpeg 208w, http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.19.51-PM-768x1107.jpeg 768w, http://35.184.23.199/wp-content/uploads/2018/03/WhatsApp-Image-2018-03-26-at-9.19.51-PM.jpeg 790w" sizes="(max-width: 710px) 100vw, 710px" />											
                <p>
                    As a international student studying in Monash University and will graduate in July. I would like to use the website to find the most suitable state for me to settle. In fact, I am searching for jobs these days and it is hard to find a job which matches my skills. However, this website helps me a lot to get rid of this confusing situation. According to the recommendations given by the website, I am now applying PR to migrate Northern Territory, 
                </p>
                <p>Mark Yang</p>